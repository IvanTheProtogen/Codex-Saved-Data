return (function()
    local CRYPTlIIIIlIl =
        "\108\111\108\32\121\111\117\32\104\97\118\101\32\116\111\32\115\116\111\112\32\116\114\121\105\110\103\32\116\111\32\100\101\111\98\102\117\115\99\97\116\101"
    local CRYPTlIIIIlIl =
        "\108\111\108\32\121\111\117\32\104\97\118\101\32\116\111\32\115\116\111\112\32\116\114\121\105\110\103\32\116\111\32\100\101\111\98\102\117\115\99\97\116\101"
    local CRYPTlIIIIlIl =
        "\108\111\108\32\121\111\117\32\104\97\118\101\32\116\111\32\115\116\111\112\32\116\114\121\105\110\103\32\116\111\32\100\101\111\98\102\117\115\99\97\116\101"
    local CRYPTlIIllllI = 207
    local CRYPTlIIlllIl = 31
    local CRYPTlIIlllII = 3
    local FirstFunction = function(a) 
    	print("FirstFunction has been used!") 
    	print("First Argument Data: "..tostring(a))
        local b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        a = string.gsub(a, "[^" .. b .. "=]", "")
        return a:gsub(
            ".",
            function(c)
            	print("The first function of the first function has been used!")
            	print("First Argument Data: "..tostring(c))
                if c == "=" then
                    return ""
                end
                local d, e = "", b:find(c) - 1 
                print("`for` used!")
                for f = 6, 1, -1 do 
                	print("Index = "..tostring(f))
                	print("Setting D variable from "..tostring(d).." to "..tostring(d .. (e % 2 ^ f - e % 2 ^ (f - 1) > 0 and "1" or "0")))
                    d = d .. (e % 2 ^ f - e % 2 ^ (f - 1) > 0 and "1" or "0")
                end 
                print("`for` finished!")
                print("Returning "..tostring(d).."!") 
                print("Closing the first function of the first function!")
                return d
            end
        ):gsub(
            "%d%d%d?%d?%d?%d?%d?%d?",
            function(c) 
            	print("The second function of the first function has been used!") 
            	print("First Argument Data: "..tostring(c))
                if #c ~= 8 then 
                	print("First Argument isn't 8! Returning a blank string!")
                	print("Closing the second function of the first function!")
                    return ""
                end
                local g = 0 
                print("`for` used!")
                for f = 1, 8 do 
                	print("Index = "..tostring(f))
                	print("Setting G from "..tostring(g).." to "..tostring(g + (c:sub(f, f) == "1" and 2 ^ (8 - f) or 0)))
                    g = g + (c:sub(f, f) == "1" and 2 ^ (8 - f) or 0)
                end 
                print("`for` finished!")
                print("Returning "..tostring(string.char(g)).." !")
                print("Closing the second function of the first function!")
                return string.char(g)
            end
        )
    end
    local CRYPTlIIlllIl = 250
    local CRYPTlIIlIlIl = (function()
        local function a(b)
            local c = {}
            for d = 0, 255 do
                c[d] = {}
            end
            c[0][0] = b[1] * 255
            local e = 1
            for f = 0, 7 do
                for d = 0, e - 1 do
                    for g = 0, e - 1 do
                        local h = c[d][g] - b[1] * e
                        c[d][g + e] = h + b[2] * e
                        c[d + e][g] = h + b[3] * e
                        c[d + e][g + e] = h + b[4] * e
                    end
                end
                e = e * 2
            end
            return c
        end
        local i = a {0, 1, 1, 0}
        local function j(self, k)
            local l, d, g = self.S, self.i, self.j
            local m = {}
            local n = string.char
            for o = 1, k do
                d = (d + 1) % 256
                g = (g + l[d]) % 256
                l[d], l[g] = l[g], l[d]
                m[o] = n(l[(l[d] + l[g]) % 256])
            end
            self.i, self.j = d, g
            return table.concat(m)
        end
        local function p(self, q)
            local r = j(self, #q)
            local s = {}
            local t = string.byte
            local n = string.char
            for d = 1, #q do
                s[d] = n(i[t(q, d)][t(r, d)])
            end
            return table.concat(s)
        end
        local function u(self, v)
            local l = self.S
            local g, w = 0, #v
            local t = string.byte
            for d = 0, 255 do
                g = (g + l[d] + t(v, d % w + 1)) % 256
                l[d], l[g] = l[g], l[d]
            end
        end
        function new(v)
            local l = {}
            local s = {S = l, i = 0, j = 0, generate = j, cipher = p, schedule = u}
            for d = 0, 255 do
                l[d] = d
            end
            if v then
                s:schedule(v)
            end
            return s
        end
        return new
    end)()
    local CRYPTlIIlIlII =
        (function()
        if not bit then
            local bit_ = nil
            pcall(
                function()
                    bit_ = require("bit")
                end
            )
            bit = bit_
        end
        local bit =
            bit or bit32 or
            (function()
                local a = {_TYPE = "module", _NAME = "bit.numberlua", _VERSION = "0.3.1.20120131"}
                local b = math.floor
                local c = 2 ^ 32
                local d = c - 1
                local function e(f)
                    local g = {}
                    local h = setmetatable({}, g)
                    function g:__index(i)
                        local j = f(i)
                        h[i] = j
                        return j
                    end
                    return h
                end
                local function k(h, l)
                    local function m(n, o)
                        local p, q = 0, 1
                        while n ~= 0 and o ~= 0 do
                            local r, s = n % l, o % l
                            p = p + h[r][s] * q
                            n = (n - r) / l
                            o = (o - s) / l
                            q = q * l
                        end
                        p = p + (n + o) * q
                        return p
                    end
                    return m
                end
                local function t(h)
                    local u = k(h, 2 ^ 1)
                    local v =
                        e(
                        function(n)
                            return e(
                                function(o)
                                    return u(n, o)
                                end
                            )
                        end
                    )
                    return k(v, 2 ^ (h.n or 1))
                end
                function a.tobit(w)
                    return w % 2 ^ 32
                end
                a.bxor = t {[0] = {[0] = 0, [1] = 1}, [1] = {[0] = 1, [1] = 0}, n = 4}
                local x = a.bxor
                function a.bnot(n)
                    return d - n
                end
                local y = a.bnot
                function a.band(n, o)
                    return (n + o - x(n, o)) / 2
                end
                local z = a.band
                function a.bor(n, o)
                    return d - z(d - n, d - o)
                end
                local A = a.bor
                local B, C
                function a.rshift(n, D)
                    if D < 0 then
                        return B(n, -D)
                    end
                    return b(n % 2 ^ 32 / 2 ^ D)
                end
                C = a.rshift
                function a.lshift(n, D)
                    if D < 0 then
                        return C(n, -D)
                    end
                    return n * 2 ^ D % 2 ^ 32
                end
                B = a.lshift
                function a.tohex(w, E)
                    E = E or 8
                    local F
                    if E <= 0 then
                        if E == 0 then
                            return ""
                        end
                        F = true
                        E = -E
                    end
                    w = z(w, 16 ^ E - 1)
                    return ("%0" .. E .. (F and "X" or "x")):format(w)
                end
                local G = a.tohex
                function a.extract(E, H, I)
                    I = I or 1
                    return z(C(E, H), 2 ^ I - 1)
                end
                local J = a.extract
                function a.replace(E, j, H, I)
                    I = I or 1
                    local K = 2 ^ I - 1
                    j = z(j, K)
                    local L = y(B(K, H))
                    return z(E, L) + B(j, H)
                end
                local M = a.replace
                function a.bswap(w)
                    local n = z(w, 0xff)
                    w = C(w, 8)
                    local o = z(w, 0xff)
                    w = C(w, 8)
                    local N = z(w, 0xff)
                    w = C(w, 8)
                    local O = z(w, 0xff)
                    return B(B(B(n, 8) + o, 8) + N, 8) + O
                end
                local P = a.bswap
                function a.rrotate(w, D)
                    D = D % 32
                    local Q = z(w, 2 ^ D - 1)
                    return C(w, D) + B(Q, 32 - D)
                end
                local R = a.rrotate
                function a.lrotate(w, D)
                    return R(w, -D)
                end
                local S = a.lrotate
                a.rol = a.lrotate
                a.ror = a.rrotate
                function a.arshift(w, D)
                    local T = C(w, D)
                    if w >= 0x80000000 then
                        T = T + B(2 ^ D - 1, 32 - D)
                    end
                    return T
                end
                local U = a.arshift
                function a.btest(w, V)
                    return z(w, V) ~= 0
                end
                a.bit32 = {}
                local function W(w)
                    return (-1 - w) % c
                end
                a.bit32.bnot = W
                local function X(n, o, N, ...)
                    local T
                    if o then
                        n = n % c
                        o = o % c
                        T = x(n, o)
                        if N then
                            T = X(T, N, ...)
                        end
                        return T
                    elseif n then
                        return n % c
                    else
                        return 0
                    end
                end
                a.bit32.bxor = X
                local function Y(n, o, N, ...)
                    local T
                    if o then
                        n = n % c
                        o = o % c
                        T = (n + o - x(n, o)) / 2
                        if N then
                            T = Y(T, N, ...)
                        end
                        return T
                    elseif n then
                        return n % c
                    else
                        return d
                    end
                end
                a.bit32.band = Y
                local function Z(n, o, N, ...)
                    local T
                    if o then
                        n = n % c
                        o = o % c
                        T = d - z(d - n, d - o)
                        if N then
                            T = Z(T, N, ...)
                        end
                        return T
                    elseif n then
                        return n % c
                    else
                        return 0
                    end
                end
                a.bit32.bor = Z
                function a.bit32.btest(...)
                    return Y(...) ~= 0
                end
                function a.bit32.lrotate(w, D)
                    return S(w % c, D)
                end
                function a.bit32.rrotate(w, D)
                    return R(w % c, D)
                end
                function a.bit32.lshift(w, D)
                    if D > 31 or D < -31 then
                        return 0
                    end
                    return B(w % c, D)
                end
                function a.bit32.rshift(w, D)
                    if D > 31 or D < -31 then
                        return 0
                    end
                    return C(w % c, D)
                end
                function a.bit32.arshift(w, D)
                    w = w % c
                    if D >= 0 then
                        if D > 31 then
                            return w >= 0x80000000 and d or 0
                        else
                            local T = C(w, D)
                            if w >= 0x80000000 then
                                T = T + B(2 ^ D - 1, 32 - D)
                            end
                            return T
                        end
                    else
                        return B(w, -D)
                    end
                end
                function a.bit32.extract(w, H, ...)
                    local I = ... or 1
                    if H < 0 or H > 31 or I < 0 or H + I > 32 then
                        error "out of range"
                    end
                    w = w % c
                    return J(w, H, ...)
                end
                function a.bit32.replace(w, j, H, ...)
                    local I = ... or 1
                    if H < 0 or H > 31 or I < 0 or H + I > 32 then
                        error "out of range"
                    end
                    w = w % c
                    j = j % c
                    return M(w, j, H, ...)
                end
                a.bit = {}
                function a.bit.tobit(w)
                    w = w % c
                    if w >= 0x80000000 then
                        w = w - c
                    end
                    return w
                end
                local _ = a.bit.tobit
                function a.bit.tohex(w, ...)
                    return G(w % c, ...)
                end
                function a.bit.bnot(w)
                    return _(y(w % c))
                end
                local function a0(n, o, N, ...)
                    if N then
                        return a0(a0(n, o), N, ...)
                    elseif o then
                        return _(A(n % c, o % c))
                    else
                        return _(n)
                    end
                end
                a.bit.bor = a0
                local function a1(n, o, N, ...)
                    if N then
                        return a1(a1(n, o), N, ...)
                    elseif o then
                        return _(z(n % c, o % c))
                    else
                        return _(n)
                    end
                end
                a.bit.band = a1
                local function a2(n, o, N, ...)
                    if N then
                        return a2(a2(n, o), N, ...)
                    elseif o then
                        return _(x(n % c, o % c))
                    else
                        return _(n)
                    end
                end
                a.bit.bxor = a2
                function a.bit.lshift(w, E)
                    return _(B(w % c, E % 32))
                end
                function a.bit.rshift(w, E)
                    return _(C(w % c, E % 32))
                end
                function a.bit.arshift(w, E)
                    return _(U(w % c, E % 32))
                end
                function a.bit.rol(w, E)
                    return _(S(w % c, E % 32))
                end
                function a.bit.ror(w, E)
                    return _(R(w % c, E % 32))
                end
                function a.bit.bswap(w)
                    return _(P(w % c))
                end
                return a
            end)()
        local unpack = table.unpack or unpack
        local a3
        local a4
        local a5
        local a6 = 50
        local a7 = {
            [22] = 18,
            [31] = 8,
            [33] = 28,
            [0] = 3,
            [1] = 13,
            [2] = 23,
            [26] = 33,
            [12] = 1,
            [13] = 6,
            [14] = 10,
            [15] = 16,
            [16] = 20,
            [17] = 26,
            [18] = 30,
            [19] = 36,
            [3] = 0,
            [4] = 2,
            [5] = 4,
            [6] = 7,
            [7] = 9,
            [8] = 12,
            [9] = 14,
            [10] = 17,
            [20] = 19,
            [21] = 22,
            [23] = 24,
            [24] = 27,
            [25] = 29,
            [27] = 32,
            [32] = 34,
            [34] = 37,
            [11] = 5,
            [28] = 11,
            [29] = 15,
            [30] = 21,
            [35] = 25,
            [36] = 31,
            [37] = 35
        }
        local a8 = {
            [0] = "ABC",
            "ABx",
            "ABC",
            "ABC",
            "ABC",
            "ABx",
            "ABC",
            "ABx",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "AsBx",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "ABC",
            "AsBx",
            "AsBx",
            "ABC",
            "ABC",
            "ABC",
            "ABx",
            "ABC"
        }
        local a9 = {
            [0] = {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgK", c = "OpArgN"},
            {b = "OpArgU", c = "OpArgU"},
            {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgU", c = "OpArgN"},
            {b = "OpArgK", c = "OpArgN"},
            {b = "OpArgR", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgN"},
            {b = "OpArgU", c = "OpArgN"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgU", c = "OpArgU"},
            {b = "OpArgR", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgR", c = "OpArgR"},
            {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgK", c = "OpArgK"},
            {b = "OpArgR", c = "OpArgU"},
            {b = "OpArgR", c = "OpArgU"},
            {b = "OpArgU", c = "OpArgU"},
            {b = "OpArgU", c = "OpArgU"},
            {b = "OpArgU", c = "OpArgN"},
            {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgR", c = "OpArgN"},
            {b = "OpArgN", c = "OpArgU"},
            {b = "OpArgU", c = "OpArgU"},
            {b = "OpArgN", c = "OpArgN"},
            {b = "OpArgU", c = "OpArgN"},
            {b = "OpArgU", c = "OpArgN"}
        }
        local function aa(ab, s, e, d)
            local ac = 0
            for i = s, e, d do
                ac = ac + string.byte(ab, i, i) * 256 ^ (i - s)
            end
            return ac
        end
        local function ad(ae, af, ag, ah)
            local ai = (-1) ^ bit.rshift(ah, 7)
            local aj = bit.rshift(ag, 7) + bit.lshift(bit.band(ah, 0x7F), 1)
            local ak = ae + bit.lshift(af, 8) + bit.lshift(bit.band(ag, 0x7F), 16)
            local al = 1
            if aj == 0 then
                if ak == 0 then
                    return ai * 0
                else
                    al = 0
                    aj = 1
                end
            elseif aj == 0x7F then
                if ak == 0 then
                    return ai * 1 / 0
                else
                    return ai * 0 / 0
                end
            end
            return ai * 2 ^ (aj - 127) * (1 + al / 2 ^ 23)
        end
        local function am(ae, af, ag, ah, an, ao, ap, aq)
            local ai = (-1) ^ bit.rshift(aq, 7)
            local aj = bit.lshift(bit.band(aq, 0x7F), 4) + bit.rshift(ap, 4)
            local ak = bit.band(ap, 0x0F) * 2 ^ 48
            local al = 1
            ak = ak + ao * 2 ^ 40 + an * 2 ^ 32 + ah * 2 ^ 24 + ag * 2 ^ 16 + af * 2 ^ 8 + ae
            if aj == 0 then
                if ak == 0 then
                    return ai * 0
                else
                    al = 0
                    aj = 1
                end
            elseif aj == 0x7FF then
                if ak == 0 then
                    return ai * 1 / 0
                else
                    return ai * 0 / 0
                end
            end
            return ai * 2 ^ (aj - 1023) * (al + ak / 2 ^ 52)
        end
        local function ar(ab, s, e)
            return aa(ab, s, e - 1, 1)
        end
        local function as(ab, s, e)
            return aa(ab, e - 1, s, -1)
        end
        local function at(ab, s)
            return ad(string.byte(ab, s, s + 3))
        end
        local function au(ab, s)
            local ae, af, ag, ah = string.byte(ab, s, s + 3)
            return ad(ah, ag, af, ae)
        end
        local function av(ab, s)
            return am(string.byte(ab, s, s + 7))
        end
        local function aw(ab, s)
            local ae, af, ag, ah, an, ao, ap, aq = string.byte(ab, s, s + 7)
            return am(aq, ap, ao, an, ah, ag, af, ae)
        end
        local ax = {[4] = {little = at, big = au}, [8] = {little = av, big = aw}}
        local function ay(S)
            local az = S.index
            local aA = string.byte(S.source, az, az)
            S.index = az + 1
            return aA
        end
        local function aB(S, aC)
            local aD = S.index + aC
            local aE = string.sub(S.source, S.index, aD - 1)
            S.index = aD
            return aE
        end
        local function aF(S)
            local aC = S:s_szt()
            local aE
            if aC ~= 0 then
                aE = string.sub(aB(S, aC), 1, -2)
            end
            return aE
        end
        local function aG(aC, aH)
            return function(S)
                local aD = S.index + aC
                local aI = aH(S.source, S.index, aD)
                S.index = aD
                return aI
            end
        end
        local function aJ(aC, aH)
            return function(S)
                local aK = aH(S.source, S.index)
                S.index = S.index + aC
                return aK
            end
        end
        local function aL(S)
            local aM = S:s_int()
            local aN = {}
            for i = 1, aM do
                local aO = S:s_ins()
                local aP = bit.band(aO, 0x3F)
                local aQ = a8[aP]
                local aR = a9[aP]
                local aS = {value = aO, op = a7[aP], A = bit.band(bit.rshift(aO, 6), 0xFF)}
                if aQ == "ABC" then
                    aS.B = bit.band(bit.rshift(aO, 23), 0x1FF)
                    aS.C = bit.band(bit.rshift(aO, 14), 0x1FF)
                    aS.is_KB = aR.b == "OpArgK" and aS.B > 0xFF
                    aS.is_KC = aR.c == "OpArgK" and aS.C > 0xFF
                elseif aQ == "ABx" then
                    aS.Bx = bit.band(bit.rshift(aO, 14), 0x3FFFF)
                    aS.is_K = aR.b == "OpArgK"
                elseif aQ == "AsBx" then
                    aS.sBx = bit.band(bit.rshift(aO, 14), 0x3FFFF) - 131071
                end
                aN[i] = aS
            end
            return aN
        end
        local function aT(S)
            local aM = S:s_int()
            local aU = {}
            for i = 1, aM do
                local aV = ay(S)
                local k
                if aV == 1 then
                    k = ay(S) ~= 0
                elseif aV == 3 then
                    k = S:s_num()
                elseif aV == 4 then
                    k = aF(S)
                end
                aU[i] = k
            end
            return aU
        end
        local function aW(S, ab)
            local aM = S:s_int()
            local aX = {}
            for i = 1, aM do
                aX[i] = a5(S, ab)
            end
            return aX
        end
        local function aY(S)
            local aM = S:s_int()
            local aZ = {}
            for i = 1, aM do
                aZ[i] = S:s_int()
            end
            return aZ
        end
        local function a_(S)
            local aM = S:s_int()
            local b0 = {}
            for i = 1, aM do
                b0[i] = {varname = aF(S), startpc = S:s_int(), endpc = S:s_int()}
            end
            return b0
        end
        local function b1(S)
            local aM = S:s_int()
            local b2 = {}
            for i = 1, aM do
                b2[i] = aF(S)
            end
            return b2
        end
        function a5(S, b3)
            local b4 = {}
            local ab = aF(S) or b3
            b4.source = ab
            S:s_int()
            S:s_int()
            b4.numupvals = ay(S)
            b4.numparams = ay(S)
            ay(S)
            ay(S)
            b4.code = aL(S)
            b4.const = aT(S)
            b4.subs = aW(S, ab)
            b4.lines = aY(S)
            a_(S)
            b1(S)
            for _, v in ipairs(b4.code) do
                if v.is_K then
                    v.const = b4.const[v.Bx + 1]
                else
                    if v.is_KB then
                        v.const_B = b4.const[v.B - 0xFF]
                    end
                    if v.is_KC then
                        v.const_C = b4.const[v.C - 0xFF]
                    end
                end
            end
            return b4
        end
        function a3(ab)
            local b5
            local b6
            local b7
            local b8
            local b9
            local ba
            local bb
            local bc = {index = 1, source = ab}
            assert(aB(bc, 4) == "\27Lua", "invalid Lua signature")
            assert(ay(bc) == 0x51, "invalid Lua version")
            assert(ay(bc) == 0, "invalid Lua format")
            b6 = ay(bc) ~= 0
            b7 = ay(bc)
            b8 = ay(bc)
            b9 = ay(bc)
            ba = ay(bc)
            bb = ay(bc) ~= 0
            b5 = b6 and ar or as
            bc.s_int = aG(b7, b5)
            bc.s_szt = aG(b8, b5)
            bc.s_ins = aG(b9, b5)
            if bb then
                bc.s_num = aG(ba, b5)
            elseif ax[ba] then
                bc.s_num = aJ(ba, ax[ba][b6 and "little" or "big"])
            else
                error("unsupported float size")
            end
            return a5(bc, "@virtual")
        end
        local function bd(be, bf)
            for i, bg in pairs(be) do
                if bg.index >= bf then
                    bg.value = bg.store[bg.index]
                    bg.store = bg
                    bg.index = "value"
                    be[i] = nil
                end
            end
        end
        local function bh(be, bf, bi)
            local bj = be[bf]
            if not bj then
                bj = {index = bf, store = bi}
                be[bf] = bj
            end
            return bj
        end
        local function bk(...)
            return select("#", ...), {...}
        end
        local function bl(bm, bn)
            local ab = bm.source
            local bo = bm.lines[bm.pc - 1]
            local b3, bp, bq = string.match(bn, "^(.-):(%d+):%s+(.+)")
            local br = "%s:%i: [%s:%i] %s"
            bo = bo or "0"
            b3 = b3 or "?"
            bp = bp or "0"
            bq = bq or bn
            error(string.format(br, ab, bo, b3, bp, bq), 0)
        end
        local function bs(bm)
            local aN = bm.code
            local bt = bm.subs
            local bu = bm.env
            local bv = bm.upvals
            local bw = bm.varargs
            local bx = -1
            local by = {}
            local bi = bm.stack
            local bz = bm.pc
            while true do
                local bA = aN[bz]
                local aP = bA.op
                bz = bz + 1
                if aP < 18 then
                    if aP < 8 then
                        if aP < 3 then
                            if aP < 1 then
                                for i = bA.A, bA.B do
                                    bi[i] = nil
                                end
                            elseif aP > 1 then
                                local bg = bv[bA.B]
                                bi[bA.A] = bg.store[bg.index]
                            else
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                bi[bA.A] = bB + bC
                            end
                        elseif aP > 3 then
                            if aP < 6 then
                                if aP > 4 then
                                    local A = bA.A
                                    local B = bA.B
                                    local bf
                                    if bA.is_KC then
                                        bf = bA.const_C
                                    else
                                        bf = bi[bA.C]
                                    end
                                    bi[A + 1] = bi[B]
                                    bi[A] = bi[B][bf]
                                else
                                    bi[bA.A] = bu[bA.const]
                                end
                            elseif aP > 6 then
                                local bf
                                if bA.is_KC then
                                    bf = bA.const_C
                                else
                                    bf = bi[bA.C]
                                end
                                bi[bA.A] = bi[bA.B][bf]
                            else
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                bi[bA.A] = bB - bC
                            end
                        else
                            bi[bA.A] = bi[bA.B]
                        end
                    elseif aP > 8 then
                        if aP < 13 then
                            if aP < 10 then
                                bu[bA.const] = bi[bA.A]
                            elseif aP > 10 then
                                if aP < 12 then
                                    local A = bA.A
                                    local B = bA.B
                                    local C = bA.C
                                    local bD
                                    local bE, bF
                                    if B == 0 then
                                        bD = bx - A
                                    else
                                        bD = B - 1
                                    end
                                    bE, bF = bk(bi[A](unpack(bi, A + 1, A + bD)))
                                    if C == 0 then
                                        bx = A + bE - 1
                                    else
                                        bE = C - 1
                                    end
                                    for i = 1, bE do
                                        bi[A + i - 1] = bF[i]
                                    end
                                else
                                    local bg = bv[bA.B]
                                    bg.store[bg.index] = bi[bA.A]
                                end
                            else
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                bi[bA.A] = bB * bC
                            end
                        elseif aP > 13 then
                            if aP < 16 then
                                if aP > 14 then
                                    local A = bA.A
                                    local B = bA.B
                                    local bD
                                    if B == 0 then
                                        bD = bx - A
                                    else
                                        bD = B - 1
                                    end
                                    bd(by, 0)
                                    return bk(bi[A](unpack(bi, A + 1, A + bD)))
                                else
                                    local bf, bG
                                    if bA.is_KB then
                                        bf = bA.const_B
                                    else
                                        bf = bi[bA.B]
                                    end
                                    if bA.is_KC then
                                        bG = bA.const_C
                                    else
                                        bG = bi[bA.C]
                                    end
                                    bi[bA.A][bf] = bG
                                end
                            elseif aP > 16 then
                                bi[bA.A] = {}
                            else
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                bi[bA.A] = bB / bC
                            end
                        else
                            bi[bA.A] = bA.const
                        end
                    else
                        local A = bA.A
                        local bH = bi[A + 2]
                        local bf = bi[A] + bH
                        local bI = bi[A + 1]
                        local bJ
                        if bH == math.abs(bH) then
                            bJ = bf <= bI
                        else
                            bJ = bf >= bI
                        end
                        if bJ then
                            bi[bA.A] = bf
                            bi[bA.A + 3] = bf
                            bz = bz + bA.sBx
                        end
                    end
                elseif aP > 18 then
                    if aP < 28 then
                        if aP < 23 then
                            if aP < 20 then
                                bi[bA.A] = #bi[bA.B]
                            elseif aP > 20 then
                                if aP < 22 then
                                    local A = bA.A
                                    local B = bA.B
                                    local bK = {}
                                    local aM
                                    if B == 0 then
                                        aM = bx - A + 1
                                    else
                                        aM = B - 1
                                    end
                                    for i = 1, aM do
                                        bK[i] = bi[A + i - 1]
                                    end
                                    bd(by, 0)
                                    return aM, bK
                                else
                                    local aE = bi[bA.B]
                                    for i = bA.B + 1, bA.C do
                                        aE = aE .. bi[i]
                                    end
                                    bi[bA.A] = aE
                                end
                            else
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                bi[bA.A] = bB % bC
                            end
                        elseif aP > 23 then
                            if aP < 26 then
                                if aP > 24 then
                                    bd(by, bA.A)
                                else
                                    local bB, bC
                                    if bA.is_KB then
                                        bB = bA.const_B
                                    else
                                        bB = bi[bA.B]
                                    end
                                    if bA.is_KC then
                                        bC = bA.const_C
                                    else
                                        bC = bi[bA.C]
                                    end
                                    if bB == bC == (bA.A ~= 0) then
                                        bz = bz + aN[bz].sBx
                                    end
                                    bz = bz + 1
                                end
                            elseif aP > 26 then
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                if bB < bC == (bA.A ~= 0) then
                                    bz = bz + aN[bz].sBx
                                end
                                bz = bz + 1
                            else
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                bi[bA.A] = bB ^ bC
                            end
                        else
                            bi[bA.A] = bA.B ~= 0
                            if bA.C ~= 0 then
                                bz = bz + 1
                            end
                        end
                    elseif aP > 28 then
                        if aP < 33 then
                            if aP < 30 then
                                local bB, bC
                                if bA.is_KB then
                                    bB = bA.const_B
                                else
                                    bB = bi[bA.B]
                                end
                                if bA.is_KC then
                                    bC = bA.const_C
                                else
                                    bC = bi[bA.C]
                                end
                                if bB <= bC == (bA.A ~= 0) then
                                    bz = bz + aN[bz].sBx
                                end
                                bz = bz + 1
                            elseif aP > 30 then
                                if aP < 32 then
                                    local aX = bt[bA.Bx + 1]
                                    local bL = aX.numupvals
                                    local bM
                                    if bL ~= 0 then
                                        bM = {}
                                        for i = 1, bL do
                                            local bN = aN[bz + i - 1]
                                            if bN.op == a7[0] then
                                                bM[i - 1] = bh(by, bN.B, bi)
                                            elseif bN.op == a7[4] then
                                                bM[i - 1] = bv[bN.B]
                                            end
                                        end
                                        bz = bz + bL
                                    end
                                    bi[bA.A] = a4(aX, bu, bM)
                                else
                                    local A = bA.A
                                    local B = bA.B
                                    if not bi[B] == (bA.C ~= 0) then
                                        bz = bz + 1
                                    else
                                        bi[A] = bi[B]
                                    end
                                end
                            else
                                bi[bA.A] = -bi[bA.B]
                            end
                        elseif aP > 33 then
                            if aP < 36 then
                                if aP > 34 then
                                    local A = bA.A
                                    local aM = bA.B
                                    if aM == 0 then
                                        aM = bw.size
                                        bx = A + aM - 1
                                    end
                                    for i = 1, aM do
                                        bi[A + i - 1] = bw.list[i]
                                    end
                                else
                                    local A = bA.A
                                    local bO, bI, bH
                                    bO = assert(tonumber(bi[A]), "`for` initial value must be a number")
                                    bI = assert(tonumber(bi[A + 1]), "`for` limit must be a number")
                                    bH = assert(tonumber(bi[A + 2]), "`for` step must be a number")
                                    bi[A] = bO - bH
                                    bi[A + 1] = bI
                                    bi[A + 2] = bH
                                    bz = bz + bA.sBx
                                end
                            elseif aP > 36 then
                                local A = bA.A
                                local C = bA.C
                                local aM = bA.B
                                local bP = bi[A]
                                local bQ
                                if aM == 0 then
                                    aM = bx - A
                                end
                                if C == 0 then
                                    C = bA[bz].value
                                    bz = bz + 1
                                end
                                bQ = (C - 1) * a6
                                for i = 1, aM do
                                    bP[i + bQ] = bi[A + i]
                                end
                            else
                                bi[bA.A] = not bi[bA.B]
                            end
                        else
                            if not bi[bA.A] == (bA.C ~= 0) then
                                bz = bz + 1
                            end
                        end
                    else
                        local A = bA.A
                        local aH = bi[A]
                        local bR = bi[A + 1]
                        local bf = bi[A + 2]
                        local bS = A + 3
                        local bK
                        bi[bS + 2] = bf
                        bi[bS + 1] = bR
                        bi[bS] = aH
                        bK = {aH(bR, bf)}
                        for i = 1, bA.C do
                            bi[bS + i - 1] = bK[i]
                        end
                        if bi[bS] ~= nil then
                            bi[A + 2] = bi[bS]
                        else
                            bz = bz + 1
                        end
                    end
                else
                    bz = bz + bA.sBx
                end
                bm.pc = bz
            end
        end
        function a4(bR, bu, b2)
            local bT = bR.code
            local bU = bR.subs
            local bV = bR.lines
            local bW = bR.source
            local bX = bR.numparams
            local function bY(...)
                local bi = {}
                local bZ = {}
                local b_ = 0
                local c0, c1 = bk(...)
                local bm
                local c2, bn, bK
                for i = 1, bX do
                    bi[i - 1] = c1[i]
                end
                if bX < c0 then
                    b_ = c0 - bX
                    for i = 1, b_ do
                        bZ[i] = c1[bX + i]
                    end
                end
                bm = {
                    varargs = {list = bZ, size = b_},
                    code = bT,
                    subs = bU,
                    lines = bV,
                    source = bW,
                    env = bu,
                    upvals = b2,
                    stack = bi,
                    pc = 1
                }
                c2, bn, bK = pcall(bs, bm, ...)
                if c2 then
                    return unpack(bK, 1, bn)
                else
                    bl(bm, bn)
                end
                return
            end
            return bY
        end
        return function(c3, bu)
            return a4(a3(c3), bu or getfenv(0))
        end
    end)()
    local CRYPTlIIllIIl =
        "\108\111\108\32\121\111\117\32\104\97\118\101\32\116\111\32\115\116\111\112\32\116\114\121\105\110\103\32\116\111\32\100\101\111\98\102\117\115\99\97\116\101"
    local CRYPTlIIlIIIl =
        "\103\102\51\118\120\76\83\113\101\76\108\69\48\54\71\80\65\121\56\110\67\69\119\67\50\88\72\101\82\119\76\54\89\102\110\65\107\115\84\71\68\101\111\88\56\83\68\116\55\101\99\73\107\105\70\50\89\67\65\47\51\116\121\54\110\72\120\84\54\70\67\69\55\79\77\83\52\112\66\83\117\71\50\57\111\121\83\69\112\104\111\97\116\79\98\83\48\53\70\68\51\115\86\111\47\70\104\117\74\79\109\50\101\74\116\74\76\69\75\99\43\74\90\75\98\56\70\105\97\85\71\86\114\107\107\57\105\67\89\90\119\120\89\112\104\105\66\49\111\119\114\110\80\55\81\97\104\79\100\70\83\88\54\74\100\55\112\98\107\68\77\109\50\119\52\121\65\71\105\66\82\106\54\85\89\118\67\120\114\81\117\68\121\82\118\85\71\51\77\97\50\86\115\98\113\89\78\100\89\115\72\87\89\120\85\87\78\104\101\43\72\112\122\109\98\53\84\56\112\48\101\70\113\79\115\105\80\86\43\102\122\75\74\70\115\78\71\101\49\116\51\90\69\81\79\115\88\52\79\76\121\103\52\78\120\56\51\87\50\105\50\88\99\117\68\80\49\47\105\71\98\77\113\109\112\100\81\53\87\97\80\115\116\110\55\57\54\121\108\53\53\117\80\75\51\54\111\52\89\71\116\99\83\103\80\84\71\73\89\98\88\104\108\78\114\56\87\103\104\101\104\73\97\100\79\87\48\104\105\67\65\87\72\77\119\113\83\49\70\72\52\55\52\87\68\116\89\98\48\80\113\108\104\75\53\119\85\76\70\56\71\83\109\103\72\47\113\47\113\83\121\50\82\70\79\51\109\79\116\118\48\121\83\77\110\82\106\122\85\114\84\71\77\116\54\116\55\57\87\86\77\77\75\73\86\66\49\79\85\120\104\117\47\118\65\51\97\87\43\43\114\112\98\74\69\75\114\122\50\76\53\120\109\110\101\54\65\53\115\55\113\68\108\50\49\115\56\48\99\79\54\74\114\74\68\72\111\115\76\99\79\90\82\74\90\90\114\86\73\53\79\47\117\115\48\105\88\54\109\83\79\117\119\43\54\83\48\77\53\74\77\89\70\69\72\122\109\73\118\121\43\80\70\83\76\83\99\99\55\79\51\82\117\77\86\120\100\118\65\98\105\74\89\104\105\77\110\70\105\77\56\79\54\67\117\111\112\111\70\120\54\71\70\102\55\72\54\114\78\79\53\78\121\49\89\54\90\83\106\53\87\121\65\47\120\112\70\117\111\100\51\117\49\101\73\122\55\49\103\106\66\105\53\56\50\106\103\74\69\76\110\47\84\88\73\122\121\102\119\101\114\105\122\113\90\84\77\43\113\49\106\55\102\52\72\116\83\66\67\99\114\99\74\107\78\88\104\97\70\118\117\105\55\75\67\119\73\105\87\90\52\100\82\70\76\70\55\68\108\80\83\115\74\105\54\102\65\54\88\97\49\90\121\72\73\43\47\105\104\110\97\52\102\109\65\120\116\119\118\81\79\51\50\99\88\108\116\55\47\103\119\122\43\116\65\65\76\108\82\107\77\116\110\47\120\50\115\83\79\90\115\73\108\89\43\115\71\85\109\80\71\115\118\55\72\56\86\83\121\53\77\75\81\76\107\47\82\55\104\119\43\120\56\106\100\104\122\56\50\55\121\104\52\109\68\69\53\105\47\85\77\57\102\47\99\68\119\106\51\111\52\103\108\87\57\104\83\65\80\54\84\43\85\102\84\43\106\66\99\121\106\55\90\82\80\69\87\54\104\102\111\116\120\90\120\108\88\49\57\67\112\88\108\89\106\74\119\48\99\85\115\65\71\88\66\121\55\66\72\116\98\83\71\43\111\51\103\84\84\50\73\71\53\119\107\65\74\89\102\77\56\65\80\77\81\57\107\82\66\120\57\104\57\85\70\100\43\101\97\103\70\82\100\79\43\118\85\54\112\120\49\99\115\110\118\90\86\104\122\116\116\55\82\75\105\50\122\115\118\51\119\68\101\70\89\65\55\71\120\104\65\68\43\50\78\122\87\113\106\57\107\105\106\54\55\121\51\113\120\70\119\101\67\76\47\65\100\116\81\111\112\47\52\110\122\107\102\118\50\80\97\109\118\115\47\78\116\121\86\74\53\48\122\107\82\48\118\106\77\109\51\113\110\71\113\49\56\107\51\55\111\119\111\47\107\107\107\108\89\69\84\88\56\89\56\82\87\98\119\100\117\117\101\99\113\83\108\84\78\116\65\66\110\49\84\74\103\69\109\50\53\105\78\112\116\98\122\69\103\105\53\68\119\98\72\74\66\111\108\78\83\86\47\114\79\110\122\54\69\109\109\114\83\72\100\108\66\78\121\109\76\79\48\70\101\43\77\47\74\85\49\66\85\111\109\75\110\110\72\84\51\117\57\56\121\105\65\98\112\57\102\43\73\90\102\50\103\79\119\108\112\105\114\54\109\115\118\49\49\121\114\89\87\117\117\106\70\113\104\105\71\119\53\90\79\115\53\99\67\67\52\101\113\88\66\78\73\83\71\51\101\73\48\79\82\97\51\52\120\101\106\53\77\104\118\111\43\100\106\50\55\86\109\107\80\56\69\71\48\47\117\77\99\57\71\101\49\116\49\85\84\117\113\115\66\119\104\86\105\55\78\104\122\77\87\52\51\69\67\84\87\120\104\52\72\53\115\77\101\66\103\74\51\72\122\100\78\113\69\84\97\102\86\47\102\66\79\71\109\98\99\75\112\89\66\76\116\103\56\83\43\84\88\107\112\83\86\117\87\114\89\114\87\69\89\113\50\66\70\80\55\49\116\109\81\80\65\105\53\112\117\112\110\52\110\100\77\110\87\97\70\65\98\50\75\116\104\70\55\100\101\105\108\54\74\110\117\97\83\79\78\49\113\86\87\107\80\101\100\71\98\103\88\111\90\43\116\103\69\80\116\84\65\47\85\108\81\103\103\97\88\107\86\50\115\100\109\56\78\116\43\106\69\108\77\72\117\111\99\88\80\48\65\66\121\71\76\116\80\80\119\104\114\115\52\89\82\102\75\90\119\98\115\117\90\48\79\99\78\101\75\69\70\77\75\43\56\74\106\47\66\111\77\90\107\109\73\101\118\87\70\50\111\72\121\48\100\116\86\83\65\72\79\83\114\49\66\101\114\68\99\100\107\101\66\104\83\103\110\85\67\71\103\114\100\66\121\112\104\84\109\86\122\104\50\99\89\76\55\74\69\65\48\77\50\79\54\86\110\67\83\68\120\80\86\50\69\72\77\90\121\65\43\105\98\70\54\111\51\72\106\114\50\71\52\108\78\69\51\66\77\87\83\99\72\88\98\76\90\74\65\57\115\112\88\48\56\74\102\106\114\99\68\47\53\97\87\56\71\108\57\76\105\109\107\119\113\57\105\98\78\108\51\83\87\100\73\84\99\101\72\106\85\70\77\51\82\68\86\103\106\49\50\52\89\114\122\65\81\81\100\53\90\87\53\98\71\77\100\50\119\77\55\53\79\98\80\111\103\77\81\98\85\101\88\76\65\99\85\76\52\121\67\78\116\52\77\117\111\73\117\105\56\68\106\105\57\114\75\85\87\122\51\76\118\115\106\109\79\86\80\117\85\88\53\80\53\90\87\107\119\69\76\87\113\83\120\116\106\67\117\67\83\55\122\90\111\121\87\102\82\74\82\113\73\57\103\71\71\106\43\79\56\104\99\114\48\117\87\53\99\120\100\115\72\79\118\52\66\43\114\65\100\79\68\55\79\65\78\78\98\88\84\69\118\112\48\122\87\89\85\65\56\101\53\98\74\100\97\81\52\52\76\105\77\54\102\80\52\89\102\51\118\100\54\105\67\43\98\84\122\110\82\108\102\73\48\108\121\51\67\66\118\68\57\70\104\56\108\120\117\117\48\65\117\81\87\73\51\49\117\51\116\85\56\107\113\43\121\109\90\116\78\89\56\52\53\116\72\88\43\119\51\48\72\70\117\87\51\106\67\100\72\106\88\69\87\43\85\49\103\117\72\65\73\70\48\111\48\88\90\120\107\65\87\67\121\70\116\54\76\56\111\87\117\117\82\49\122\107\51\112\83\50\69\85\49\109\99\52\98\66\85\77\47\97\100\117\85\114\47\118\80\99\86\47\77\120\80\81\118\101\86\79\57\118\119\82\50\97\66\49\97\83\110\99\87\65\50\86\112\110\76\73\75\81\107\79\68\68\110\101\111\83\103\65\97\88\82\68\99\119\122\111\74\105\55\83\67\111\115\88\121\121\109\109\81\110\77\106\114\102\48\68\121\89\73\118\116\115\86\116\74\108\85\73\56\120\80\67\43\105\56\68\69\85\88\69\102\54\66\57\106\109\116\76\104\68\56\66\102\113\57\113\43\110\90\102\98\51\105\109\65\121\116\118\109\70\69\114\105\117\65\70\118\89\99\120\103\104\88\84\54\43\122\86\71\99\110\52\117\104\56\52\84\57\73\100\65\51\113\78\43\115\74\55\110\70\113\113\75\85\50\83\76\71\50\98\51\49\54\112\52\111\54\103\82\86\87\112\52\71\48\76\69\122\108\82\116\122\120\102\72\47\113\120\113\85\102\99\56\89\76\50\68\109\71\83\99\57\76\66\65\67\56\70\55\112\99\50\83\116\100\101\72\107\53\50\70\85\78\78\101\56\105\52\67\107\73\105\78\116\105\71\89\75\73\80\84\66\48\52\108\119\122\50\116\112\49\82\90\111\87\83\120\89\113\111\120\77\48\65\87\65\71\100\77\109\71\121\90\122\80\80\112\69\47\82\48\74\72\68\100\47\43\74\69\74\113\82\76\102\104\116\103\53\112\116\78\48\85\121\87\118\97\71\98\102\85\50\71\107\47\48\90\90\111\97\86\81\89\99\112\115\106\70\74\66\50\101\51\47\57\56\53\111\73\116\80\102\110\74\102\55\68\100\68\88\83\51\101\82\113\56\121\110\82\90\75\104\107\108\111\71\97\110\120\90\104\115\82\52\69\103\66\50\85\69\65\81\72\87\79\71\122\70\87\105\54\50\74\70\54\120\84\107\102\43\114\122\89\118\117\114\90\79\57\69\107\88\47\108\65\87\54\43\69\74\108\101\79\50\112\69\99\111\72\86\88\119\90\103\84\108\118\109\119\119\101\122\83\75\111\116\107\51\87\77\81\119\50\52\81\76\50\50\57\49\57\69\102\117\54\108\117\75\110\103\70\75\57\48\67\57\76\88\71\103\50\50\100\99\121\120\110\78\98\52\100\97\56\97\77\48\52\72\101\90\55\77\107\101\50\88\68\113\113\111\97\106\117\54\70\107\66\100\84\72\70\116\118\52\101\73\73\89\120\57\75\103\49\55\121\97\97\71\51\122\56\99\85\87\89\113\82\108\120\105\115\74\70\111\110\107\88\112\48\84\81\72\50\113\86\83\90\113\107\86\114\48\101\111\70\83\65\107\98\118\116\71\115\74\76\82\90\106\50\121\55\98\120\118\122\106\116\110\65\88\76\108\122\110\69\101\108\118\80\48\68\104\76\107\117\118\79\80\73\85\57\112\67\122\54\78\84\48\119\100\70\87\121\100\109\48\113\104\120\78\90\87\75\104\50\112\121\56\77\43\121\89\100\65\119\67\49\88\112\79\119\49\88\79\52\68\53\100\116\56\122\82\71\87\68\82\81\80\53\121\67\47\105\57\103\105\114\100\85\100\97\90\114\104\51\82\81\56\82\50\81\72\108\69\107\114\50\73\117\49\101\110\103\49\98\50\86\70\121\47\79\51\57\69\120\112\121\77\71\54\122\57\113\54\67\112\111\100\57\77\89\100\50\98\104\65\106\79\66\53\112\102\70\69\73\73\101\114\65\78\106\120\55\43\57\67\55\57\69\117\65\71\112\80\54\113\49\69\100\101\101\101\100\115\109\83\43\73\110\117\65\97\49\104\73\120\115\66\109\101\53\55\88\122\106\101\49\65\118\68\56\48\98\85\102\114\110\110\101\99\50\106\79\118\57\120\89\52\108\102\51\69\114\83\87\49\65\105\47\52\65\116\75\70\77\73\108\78\117\51\116\112\102\74\79\48\100\101\110\72\71\97\73\68\56\66\101\107\67\67\50\119\118\71\86\107\80\54\76\100\121\81\106\113\113\106\82\115\51\70\67\72\101\113\107\118\43\85\52\55\102\52\55\80\120\119\43\79\65\101\104\105\48\43\78\101\90\50\109\52\75\107\70\110\87\68\99\101\121\55\101\103\76\79\48\54\69\75\105\112\112\72\115\43\104\98\82\99\50\52\99\50\111\72\80\90\51\115\86\112\69\89\68\49\103\110\55\108\65\120\50\106\74\82\82\70\102\114\89\43\55\105\77\54\51\88\121\74\108\122\79\74\50\98\85\102\109\103\74\50\65\65\43\104\75\118\84\112\103\98\49\119\55\52\84\100\108\72\87\76\98\65\57\118\71\49\65\72\110\84\53\106\98\69\55\69\77\54\49\106\76\71\81\121\100\55\84\119\80\113\101\55\76\97\106\79\65\81\117\97\118\77\66\47\53\87\66\120\65\100\90\67\100\112\55\106\121\65\57\48\87\99\56\51\72\119\82\78\82\104\118\120\69\103\107\87\77\79\47\106\87\113\109\52\102\67\121\118\107\119\76\85\73\83\49\80\51\52\48\69\106\80\80\57\71\85\99\55\72\111\121\117\113\56\119\117\106\43\57\118\99\82\69\87\85\104\56\104\51\49\106\68\69\115\43\82\47\52\50\100\65\98\74\68\55\48\88\47\51\89\71\121\70\103\97\74\52\111\113\113\121\112\56\56\66\121\97\76\88\104\85\51\104\52\65\110\78\112\67\121\71\110\120\74\115\109\113\78\52\52\77\103\43\120\120\73\82\83\101\57\106\113\81\103\80\83\75\65\87\98\115\76\48\88\67\90\108\119\49\89\120\50\105\74\48\43\76\86\111\43\103\76\67\73\110\83\110\100"
    local CRYPTlIIllIIl =
        "\108\111\108\32\121\111\117\32\104\97\118\101\32\116\111\32\115\116\111\112\32\116\114\121\105\110\103\32\116\111\32\100\101\111\98\102\117\115\99\97\116\101"
    local CRYPTlIIllIII = "J1NnKlZuQTlLTHoiNVZqKw=="
    local CRYPTlIIlIIlI = function(a, b)
        local c = CRYPTlIIlIlIl(FirstFunction(a))
        local d = c["\99\105\112\104\101\114"](c, FirstFunction(b))
        return FirstFunction(d)
    end
    local CRYPTlIIllIll = "\100\69\120\75\100\121\57\80\98\110\70\112\86\108\112\69"
    local CRYPTlIIllIll = "\100\69\120\75\100\121\57\80\98\110\70\112\86\108\112\69"
    local CRYPTlIIllIII = "J1NnKlZuQTlLTHoiNVZqKw=="
    local CRYPTlIIlIIII = "ODd5Un03MlQyZTk4WDwzUDwyekEvL2diMy86YXgtPEYyQl0rQCY+NCR0"
    function CRYPTlIIlIlll(a, b)
        local c = FirstFunction(a, b)
        local d = CRYPTlIIllIlI
        return c, d
    end
    return CRYPTlIIlIlII(CRYPTlIIlIIlI(CRYPTlIIllIll, CRYPTlIIlIIIl), getfenv(0))()
end)()
