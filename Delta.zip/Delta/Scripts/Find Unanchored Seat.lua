for i,v in workspace:GetChildren() do
	if (v:IsA("Seat")) or (v:IsA("VehicleSeat")) then
		if not v.Anchored then
			game:GetService("Players").LocalPlayer.Character:WaitForChild("HumanoidRootPart").CFrame = v.CFrame
			wait()
		end
	end
end