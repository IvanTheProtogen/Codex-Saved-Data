loadstring(game:HttpGet("http://github.com/IvanTheProtogen/ExtraAbilities/raw/main/main.lua"))().BypassAdonisAnticheat();

loadstring(game:HttpGet('https://raw.githubusercontent.com/IvanTheProtogen/SimpleSpyV3-ForMobile/main/SimpleSpyBeta.lua.txt'))() -- SimpleSpy V3 for Mobile