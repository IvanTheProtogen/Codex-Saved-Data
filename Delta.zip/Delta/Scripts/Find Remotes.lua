for i,v in pairs(game:GetDescendants()) do
if v:IsA("RemoteEvent") or v:IsA("RemoteFunction") then
warn("Found "..v.ClassName..' "'..v.Name..'"!')
end
end