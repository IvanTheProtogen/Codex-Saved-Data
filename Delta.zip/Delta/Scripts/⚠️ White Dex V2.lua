loadstring(game:HttpGet("http://github.com/IvanTheProtogen/ExtraAbilities/raw/main/main.lua"))().BypassAdonisAnticheat();

loadstring(game:HttpGet('https://raw.githubusercontent.com/IvanTheProtogen/Raspberry-Pi-White-Dex-V2/main/mainpart'))()