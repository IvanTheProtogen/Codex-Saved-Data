local LoadStringEnabled = gethiddenproperty(game:GetService('ServerScriptService'),"LoadStringEnabled")
local HttpEnabled = game:GetService('HttpService'):GetAttribute('HttpEnabled')

local mainParent = game:GetService('CoreGui')
local ScrnGui = Instance.new("ScreenGui");ScrnGui.Parent = mainParent
local Texty = Instance.new("TextLabel");Texty.Parent = ScrnGui
Texty.Size = UDim2.new(0,240,0,80)
Texty.Position = UDim2.new(.5,-120,.5,-40)

if LoadStringEnabled and HttpEnabled then
	Texty.Text = "LoadStringEnabled and HttpEnabled are ON!"
	wait(5)
	ScrnGui:Destroy()
elseif LoadStringEnabled then
	Texty.Text = "LoadStringEnabled is ON!"
	wait(5)
	ScrnGui:Destroy()
elseif HttpEnabled then
	Texty.Text = "HttpEnabled is ON!"
	wait(5)
	ScrnGui:Destroy()
else
	ScrnGui:Destroy()
end