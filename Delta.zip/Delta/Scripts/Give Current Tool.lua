local tool = game:GetService('Players').LocalPlayer.Character:FindFirstChildWhichIsA("Tool")
local handle = tool:FindFirstChildWhichIsA("BasePart")

tool.Parent = workspace
handle.CanCollide = true
handle.Anchored = false