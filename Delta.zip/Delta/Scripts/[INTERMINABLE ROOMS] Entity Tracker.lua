local ExtraAbilities;if game:GetService("RunService"):IsClient()then ExtraAbilities=loadstring(game:HttpGet("https://raw.githubusercontent.com/IvanTheProtogen/ExtraAbilities/main/main.lua"))()else ExtraAbilities=loadstring(game:GetService("HttpService"):GetAsync("https://raw.githubusercontent.com/IvanTheProtogen/ExtraAbilities/main/main.lua"))()end;

workspace.Entities.ChildAdded:Connect(function(inst)
ExtraAbilities.Chat("[ENTITY TRACKER] "..inst.Name.." has spawned!")
ExtraAbilities.Notify("ENTITY TRACKER",inst.Name.." has spawned!")
end)

workspace.Entities.ChildRemoved:Connect(function(inst)
ExtraAbilities.Chat("[ENTITY TRACKER] "..inst.Name.." has despawned!")
ExtraAbilities.Notify("ENTITY TRACKER",inst.Name.." has despawned!")
end)

ExtraAbilities.Chat("[ENTITY TRACKER] Module has been activated!")
ExtraAbilities.Notify("ENTITY TRACKER","Module has been activated!")