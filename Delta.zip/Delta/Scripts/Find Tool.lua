for i,v in pairs(workspace:GetDescendants()) do
if v:IsA("Tool") then
pcall(function()
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v:FindFirstChildWhichIsA("BasePart").CFrame
wait(0.1)
end)
end
end