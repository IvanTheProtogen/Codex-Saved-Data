while wait() do
	script:Clone()
    game:GetService("ReplicatedStorage"):WaitForChild("Events"):WaitForChild("Morph"):FireServer({"4670879566","10","10"})
    wait()
    game:GetService("ReplicatedStorage"):WaitForChild("Events"):WaitForChild("Morph"):FireServer({"16048563967","10","10"})
end