local function ShitNCum(plr)spawn(function()pcall(function()

local HRP = plr.Character.HumanoidRootPart

local shit = Instance.new("Part")
shit.Name = "shit"
shit.Color = Color3.fromRGB(64,32,0)
shit.Size = Vector3.new(0.5,0.5,0.5)
shit.CFrame = HRP.CFrame:ToWorldSpace(CFrame.new(0,-1,1))
shit.Parent = workspace

local cum = Instance.new("Part")
cum.Name = "shit"
cum.Color = Color3.fromRGB(240,240,240)
cum.Size = Vector3.new(0.5,0.5,0.5)
cum.CFrame = HRP.CFrame:ToWorldSpace(CFrame.new(0,-1,-1))
cum.Parent = workspace

end)end)end

while wait(0.1) do 
spawn(function()
for i,v in pairs(game:GetService("Players"):GetPlayers()) do 
ShitNCum(v)
end
end)
end