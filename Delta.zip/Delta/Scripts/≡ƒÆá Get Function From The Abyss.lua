local tbll = {}

for i,v in pairs(getgc(true)) do
	if typeof(v) == "function" then
		table.insert(tbll,v)
	end
end

local tablecount = loadstring(game:HttpGet("http://github.com/IvanTheProtogen/ExtraAbilities/raw/main/main.lua"))().SmartTableItemCount

local tbl = nil
local idx=1

task.spawn(function()
task.wait()
for i,v in pairs(tbl) do
print("(",idx,")",i,"--",v,"(",typeof(v),")")
if typeof(v) == "table" then
print("└ Item Count:",tablecount(v))
elseif typeof(v) == "function" then
if islclosure(v) then
print("├ Lua Closure?: Yes")
print("├ Upvalues:",tablecount(getupvalues(v)))
print("├ Constants:",tablecount(getconstants(v)))
print("└ Protos:",tablecount(getprotos(v)))
else
print("└ Lua Closure?: No")
end
elseif typeof(v) == "Instance" then
print("├ ClassName:",v.ClassName)
if v.Parent ~= nil then
print("└ Parent:",v.Parent.Name,"(",v.Parent.ClassName,")")
else
print("└ Parent: <<NIL>>")
end
end
idx=idx+1
end
end)

local aaa = tbll[math.random(1,#tbll)]

warn("FUNCTION ID:",string.sub(tostring(aaa),13))

tbl = {aaa}