-- Working Chat Bypass lolol

loadstring(game:HttpGet('https://raw.githubusercontent.com/IvanTheProtogen/roblox-chat-bypass/main/main.lua'))();