local dummyModel = game:GetObjects('rbxassetid://12156069147')[1]
local localplr = game:GetService('Players').LocalPlayer
local localplrChar = localplr.Character
local camera = game:GetService("Workspace"):FindFirstChildWhichIsA("Camera")
local SendAbyss = Instance.new("BindableEvent")

dummyModel.Name = localplr.Name.."_DUMMY"
dummyModel.Parent = game:GetService("Workspace")
localplr.Character = dummyModel
camera.CameraSubject = dummyModel:FindFirstChildWhichIsA("Humanoid")

dummyModel:WaitForChild("HumanoidRootPart").CFrame = localplrChar:WaitForChild("HumanoidRootPart").CFrame

SendAbyss.Event:Connect(function()
	while wait() do
		localplrChar:WaitForChild("HumanoidRootPart").Position = Vector3.new(0,((2^31)-1),0)
	end
end)

SendAbyss:Fire()