local Event = game.Players.LocalPlayer.Backpack:WaitForChild("Building Tools"):WaitForChild("SyncAPI"):FindFirstChild("ServerEndpoint", true)

local CrashServer = Instance.new("BindableEvent")
CrashServer.Event:Connect(function(inst) Event:InvokeServer("SyncAnchor",{{["Part"]=inst,["Anchored"]=false}}) end)

while wait() do
	for a,b in game:GetService('Workspace'):GetChildren() do
		if #b:GetChildren() ~= 0 then
			for c,d in b:GetChildren() do
				CrashServer:Fire(d)
			end
		end
		CrashServer:Fire(b)
	end
end