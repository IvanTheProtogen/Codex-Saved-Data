local Event = game.Players.LocalPlayer.Backpack:WaitForChild("Building Tools"):WaitForChild("SyncAPI"):FindFirstChild("ServerEndpoint", true)

local function DeleteObj(obj)
	local DeleteObjMain = Instance.new("BindableEvent")
	DeleteObjMain.Event:Connect(function() Event:InvokeServer("Remove",{obj}) end)
	DeleteObjMain:Fire()
end

while wait() do
	pcall(function()
		for a,b in game:GetService("Workspace"):GetChildren() do
			if #b:GetChildren() ~= 0 then
				for c,d in b:GetChildren() do
					DeleteObj(d)
				end
			end
			DeleteObj(b)
		end
	end)
end