local function chat(msg)
	game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(msg, "All")
end

local function bkit(one, two, three, four, five)
	game:GetService('Players').LocalPlayer.Backpack.Events:FireServer(one, two, three, four, five)
end

local activeGrief
activeGrief = false

game.Players.LocalPlayer.Chatted:Connect(function(msg)
	if msg == "~start" then
		activeGrief = true
	end

	if msg == "~end" then
		activeGrief = false
	end
end)

chat("Loaded.")

while wait() do
	for a1, someone in game:GetService('Workspace').Cubes:GetChildren() do
		for b2, mrcube in someone:GetChildren() do
			if mrcube.Name == "Cube" then
				if activeGrief then
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = mrcube.CFrame
					wait()
					bkit(mrcube.Position, Enum.NormalId.Top, mrcube, Color3.new(0,0,0), "Smooth")
					wait()
				end
			end
		end
	end
end