-- Global Variable Finder

if #_G ~= 0 then
	for i,v in pairs(_G) do
		print("[Global Variable Finder] _G."..tostring(i).." = "..tostring(v))
	end
else
	warn("[Global Variable Finder] No global variable has been detected!")
end