if pcall(function() local SecuredPoint = game:GetService("Players").LocalPlayer.Character:FindFirstChild("Building Tools").SyncAPI.ServerEndpoint end) then
	game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents").SayMessageRequest:FireServer("[💠]: F3X Admin script has successfully loaded!","All")
else
	game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents").SayMessageRequest:FireServer("[💠]: F3X Admin script wouldn't load without you holding F3X tool!","All")
end

local SecuredPoint = game:GetService("Players").LocalPlayer.Character:FindFirstChild("Building Tools").SyncAPI.ServerEndpoint

local function F3X(dofunc)
	return SecuredPoint:InvokeServer(unpack(dofunc))
end

local function KillAll()
	for i,v in game:GetService('Players'):GetPlayers() do
		if v.Name ~= game:GetService('Players').LocalPlayer.Name then
			F3X({[1]="Remove",[2]={[1]=v.Character:WaitForChild('Head')}})
		end
	end
end

local function VoidAll()
	for i,v in game:GetService('Players'):GetPlayers() do
		if v.Name ~= game:GetService('Players').LocalPlayer.Name then
			F3X({[1]="Remove",[2]={[1]=v.Character}})
		end
	end
end

game:GetService('Players').LocalPlayer.Chatted:Connect(function(msg)
	if msg == "~killall" then
		KillAll()
	elseif msg == "~voidall" then
        VoidAll()
    end
end)