local CharTable = {}
for i=1,256 do
table.insert(CharTable,string.char(i-1))
end
local function RandomChar()
local str = ""
if math.random(1,16) < 11 then
str = CharTable[math.random(49,58)]
else
str = CharTable[math.random(98,103)]
end
return str
end
local function GenUUID()
local str = ""
for i=1,36 do
if i==9 or i==14 or i==19 or i==24 then
str = str.."-"
else
str = str..RandomChar()
end
end
return str
end
print(GenUUID())