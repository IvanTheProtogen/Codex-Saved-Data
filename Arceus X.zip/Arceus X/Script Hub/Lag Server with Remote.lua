while wait() do
	game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("\x006A", "All")
end