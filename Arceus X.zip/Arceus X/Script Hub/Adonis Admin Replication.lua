local function ExecuteAdonisCMD(cmd)
	for blablabla, SecuredPoint in game:GetService("JointsService"):GetChildren() do
		pcall(SecuredPoint:FireServer(unpack({[1]={["Module"]=getNil("Client","ModuleScript"),["Loader"]=getNil("ClientMover","LocalScript"),["Mode"]="Fire",["Received"]=0,["Sent"]=14},[2]="5%X\28L*(vW\"&\22*\27",[3]=cmd})))
	end
end

ExecuteAdonisCMD(":jump all")