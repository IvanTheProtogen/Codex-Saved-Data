local Event = game:GetService("Players").LocalPlayer.Character:FindFirstChild("Building Tools").SyncAPI.ServerEndpoint
wait()
script:Clone()
while wait() do
    local args = {
        [1] = "RecolorHandle",
        [2] = BrickColor.new(math.random(1000,1031))
    }
    
    Event:InvokeServer(unpack(args))
end