local Event = game:GetService("Players").LocalPlayer.Character:FindFirstChild("Building Tools").SyncAPI.ServerEndpoint
wait()
script:Clone()
while wait() do
    Event:InvokeServer("RecolorHandle",BrickColor.new(1002))
    wait()
    Event:InvokeServer("RecolorHandle",BrickColor.new(1003))
end