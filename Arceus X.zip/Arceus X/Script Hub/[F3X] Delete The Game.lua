local Event = game.Players.LocalPlayer.Backpack:WaitForChild("Building Tools"):WaitForChild("SyncAPI"):FindFirstChild("ServerEndpoint", true)

Event:InvokeServer("Remove", {game:GetService('Players').LocalPlayer.Character})

while wait() do
	for x,y in game:GetChildren() do
		Event:InvokeServer("Remove", {y})
		for i,v in y:GetChildren() do
			Event:InvokeServer("Remove", {v})
			for a,b in v:GetChildren() do
				Event:InvokeServer("Remove", {b})
			end
		end
	end
end