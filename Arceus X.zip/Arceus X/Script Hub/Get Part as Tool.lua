local a = 

a.Name = "Handle"
a.Parent = Instance.new("Tool",game:GetService('Players').LocalPlayer.Character)