local SecuredPoint = game:GetService("Players").LocalPlayer.Character:FindFirstChild("Building Tools").SyncAPI.ServerEndpoint

local Activate = Instance.new("BindableEvent")

local function F3X(dofunc)
    return SecuredPoint:InvokeServer(unpack(dofunc))
end

local function AddTrail(inst)
    F3X({[1]="CreatePart",[2]="Normal",[3]=game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame,[4]=workspace})
    
    local mainPart = workspace:GetChildren()[#workspace:GetChildren()]

    F3X({[1]="SyncCollision",[2]={[1]={["Part"]=mainPart,["CanCollide"]=false}}})
    F3X({[1]="SyncResize",[2]={[1]={["Part"]=mainPart,["CFrame"]=inst.CFrame,["Size"]=inst.Size}}})
    F3X({[1]="SyncMaterial",[2]={[1]={["Part"]=mainPart,["Transparency"]=0.9}}})
    F3X({[1]="SyncMaterial",[2]={[1]={["Part"]=mainPart,["Reflectance"]=1}}})

    Activate.Event:Connect(function()
        while wait() do
            F3X({[1]="SyncMove",[2]={[1]={["Part"]=mainPart,["CFrame"]=inst.CFrame}}})
        end
    end)
end

for i,v in game:GetService("Players").LocalPlayer.Character:GetChildren() do
    if (v:IsA("Part")) or (v:IsA("MeshPart")) then
        AddTrail(v)
    end
end

Activate:Fire()
wait(1)
Activate:Destroy()